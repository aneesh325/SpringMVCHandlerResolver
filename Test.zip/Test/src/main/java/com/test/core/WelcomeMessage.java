package com.test.core;

public class WelcomeMessage {

	
	public static String greeting(){
		return "you are in the Static method";
	}
	
	public  String welcomeGreeting(){
		return "you are in the Dynamic method";
	}
	
}
